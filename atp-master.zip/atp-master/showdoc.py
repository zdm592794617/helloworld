from collections import OrderedDict
import os
import requests
import jsonpath
import re
import yaml
from urllib.parse import urljoin

def ordered_yaml_dump(data, stream=None, Dumper=yaml.SafeDumper, **kwds):
    def dict_representer(dumper, data):
        return dumper.represent_mapping(
            yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
            data.items())

    yaml.SafeDumper.add_representer(OrderedDict, dict_representer)
    return yaml.dump(data, stream, yaml.SafeDumper, **kwds)

def get_from_swagger():
    rq = requests.get(url, verify=False).json()
    base_path = rq.get('basePath')
    paths_dic = rq.get('paths')
    for api, data in paths_dic.items():
        uri = urljoin(base_path, api)
        for m, v in data.items():
            method = m
            name = v['tags'][0] + v['summary']
            content_type = v['produces']
            parameters = jsonpath.jsonpath(data, '$..name')
            print(method)
            print(name)
            print(content_type)
            print(parameters)
path = os.path.dirname(__file__)
BASE_HOST='http://test.qtrade.com.cn'
# login_data={'username':'het@qtrade.com.cn','password':'a1234567'}
# session = requests.Session()
# req1 = session.post('http://212.129.164.73:9106/showdoc/server/index.php?s=/api/user/login',data=login_data)
# jar = session.cookies
# print(jar)
# print(req1.json())
cookie = {'cookie_token':'b242a3438bf83be30c600568c1926693bea550e53c64987146df17bc4899ae08'}
req=requests.get('http://212.129.164.73:9106/showdoc/server/index.php?s=/api/item/myList',cookies=cookie).json()
item_ids=jsonpath.jsonpath(req,'$..item_id')
item_dict={}
for item in req['data']:
    if item['item_id']!='1':
        item_dict[item['item_id']]=item['item_name']

k='22'
data = {'item_id': k}
try:
    os.mkdir(item_dict[k])
except Exception as e:
    pass
req_get_page=requests.post('http://212.129.164.73:9106/showdoc/server/index.php?s=/api/item/info',data=data,cookies=cookie).json()
page_ids = jsonpath.jsonpath(req_get_page,'$..page_id')
for page_id in page_ids:
    data = {'page_id': page_id}
    req_page_info = requests.post('http://212.129.164.73:9106/showdoc/server/index.php?s=/api/page/info',data=data,cookies=cookie).json()
    page_title= req_page_info['data']['page_title'].replace('/','_')
    page_content =req_page_info['data']['page_content']
    matched_uri = re.search(r'(/.*[a-z])', page_content)
    matched_method = re.search(r'- ([A-Z].*?) ', page_content)
    if matched_uri and matched_method:
        url = matched_uri.group(1)
        method=matched_method.group(1).upper()
        param_content=re.search(r'参数\：\*\* ([\s\S]*)\*\*返回示例\*\*',page_content).group(1)
        param = re.findall(r'\|([a-z A-Z _]*?)\|', param_content)
        data_dic=OrderedDict()
        data_dic['name']=page_title
        data_dic['url']=url
        data_dic['method']=method
        headers={'Content-Type':'application/json'}
        data_dic['headers']=headers
        if param:
            data={}
            for tmp in param[::2]:
                #json[tmp] = param[param.index(tmp) + 1]
                data[tmp.strip()] = '${'+tmp.strip()+'}'
            data_dic['data']=data
            data_file = os.path.join(item_dict[k],page_title+'.csv')
            with open(data_file,'w') as f:
                f.write(','.join([i.strip() for i in param[::2]]))
        yaml_file = os.path.join(item_dict[k],page_title+'.yaml')
        if not  os.path.exists(yaml_file):
            new_yaml_file = os.path.join(path,item_dict[k], page_title + '.yaml')
            f = open(new_yaml_file,'w',encoding='utf-8')
            ordered_yaml_dump(data_dic,f,encoding='utf-8',allow_unicode='True')
            f.close()
    else:
        print('meiyoupipei')






