import os, re, json
import jsonpath
import yagmail
import time
import traceback
from config.setting import log, TO, CC, EMAIL_INFO, CASE_PATH, PARAM_PATTERN, ENV, TEST_PROJECT
import faker
import zipfile


def check_dict(data):
    if isinstance(data, dict):
        return True
    else:
        return False

#todo校验从yaml中生成的格式是否符合格式要求
def check_testcase_format(data):
    pass
def get_value(d, k):
    '这个函数是用来从返回结果里面获取key的'
    result = jsonpath.jsonpath(d, '$..%s' % k)
    if result:
        return result[0]
    return ''


def join_path(dirname, *filename):
    return os.path.join(dirname, *filename)


def get_strftime(delt=None, format='%Y-%m-%d %H:%M:%S'):
    '''2019-09-13 00:00:00  delt 为相隔的时间一小时为3600'''
    if delt:
        timestamp = time.time() - delt
        time_tuple = time.localtime(timestamp)
        return time.strftime(format, time_tuple)
    return time.strftime(format)


def get_strftime_start(delt=None, format='%Y-%m-%d %H:%M:%S'):
    '''2019-09-13 00:00:00  delt 为相隔的时间一小时为3600'''
    return get_strftime(delt, '%Y-%m-%d 00:00:00')


def get_strftime_end(delt=None, format='%Y-%m-%d %H:%M:%S'):
    '''2019-09-13 00:00:00  delt 为相隔的时间一小时为3600'''
    return get_strftime(delt, '%Y-%m-%d 23:59:59')




def faker_data(locale='zh-CN'):
    f = faker.Faker(locale=locale)
    return f


def rex_match(rex, data):
    if check_dict(data):
        data = json.dumps(data)
    matched_data = re.findall(rex, data)
    if matched_data:
        return matched_data
    else:
        return ''


def prase_data(data):
    '''data 为json类型 <get_strftime(delt=24*3600*2,format='%Y-%m-%d 00:00:00')>'''
    rex_p = r'<(.*?)>'
    matched_data = rex_match(rex_p, data)
    if matched_data:
        for tmp in matched_data:
            try:
                data = data.replace(tmp, eval(tmp))
            except Exception as e:
                log.error(e)
                data = tmp
        data = re.sub('[<|>]', '', data)
    return data


def para_param(data):
    # ${collation}
    rex_p = r'\${(.*?)}'
    matched_data = rex_match(rex_p, data)
    return matched_data


def variable_replace(pattern, data, var_map):
    '''
    {"url": "/fund/intent-notify", "method": "get", "content_type": "*/*", "data": {"page": "${page}", "personOnly": "${personOnly}", "size": "${size}", "sortFields": "${sortFields}"}}
    {'page': '1', 'personOnly': '1', 'size': '50', 'sortFields': 'charge'}
    '''
    for temp in rex_match(pattern, data):
        if temp in var_map.keys():
            if not isinstance(data, str):
                data = str(data)
            temp_data = var_map.get(temp, '')
            try:
                data = data.replace('${' + temp + '}', temp_data)
            except:
                data = data
    return data


def depend_replace(pattern, data, var_map):
    if rex_match(pattern, data):
        for temp in rex_match(pattern, data):
            if temp in var_map.keys():
                if not isinstance(data, str):
                    data = json.dumps(data)
                data = data.replace('${' + temp + '}$', str(var_map.get(temp)))
            else:
                return data
        return json.loads(data)
    else:
        return data


def get_filename(filedir):
    '''获取目录下的所有文件,返回一个列表'''
    path = []
    for root, dirs, files in os.walk(filedir):
        for name in files:
            path.append(os.path.join(root, name))
    return path


def get_filenames(filedir, suffix):
    '''获取目录下特定后缀的文件
    '''
    path = []
    for root, dirs, files in os.walk(filedir):
        for name in files:
            if os.path.splitext(name)[1] == suffix:
                path.append(os.path.join(root, name))
    return path


def get_dir_apis():
    '''获取目录下特定后缀的文件
    :return [(目录名,[文件名,..])]
    '''
    dir_apis = {}
    if TEST_PROJECT == '':
        filedir = CASE_PATH
        for root, dirs, files in os.walk(filedir):
            for dir in dirs:
                if dir.startswith("qt"):
                    dir_path = os.path.join(root, dir)
                    dir_apis[dir] = get_filenames(dir_path, '.yaml')
    else:
        filedir = os.path.join(CASE_PATH, TEST_PROJECT)
        dir_apis[TEST_PROJECT] = get_filenames(filedir, '.yaml')
    return dir_apis


def get_dirnames(dir):
    '''返回目录以qt开头的所有目录'''
    path = []
    for root, dirs, files in os.walk(dir):
        for dir in dirs:
            if dir.startswith("qt"):
                path.append(os.path.join(root, dir))
    return path


def get_params(str):
    '''从字符串中获取{param}类型里的变量'''
    return re.findall(r'{(.*?)}', str)


# 压缩文件夹
def zip_ya(startdir):
    file_news = startdir + '.zip'  # 压缩后文件夹的名字
    z = zipfile.ZipFile(file_news, 'w', zipfile.ZIP_DEFLATED)  # 参数一：文件夹名
    for dirpath, dirnames, filenames in os.walk(startdir):
        fpath = dirpath.replace(startdir, '')  # 这一句很重要，不replace的话，就从根目录开始复制
        fpath = fpath and fpath + os.sep or ''  # 这句话理解我也点郁闷，实现当前文件夹以及包含的所有文件的压缩
        for filename in filenames:
            z.write(os.path.join(dirpath, filename), fpath + filename)
    z.close()


def send_mail(total_num, pass_count, fail_count,error_count):
    log.debug('开始发送邮件')
    subject = '%s-接口测试报告' % time.strftime('%m-%d %H:%M:%S')
    html = '''
    <div style="font-size: 16px;font-weight: 500"">大家好:</div>
<div style="line-height: 1.5;font-size: 16px;font-weight: 500">&nbsp; &nbsp;&nbsp;本次总共运行{}条用例，通过【{}】条，<span style="color: red">失败【{}】条,错误【{}】条</span></div>
<div style="line-height: 1.5;font-size: 16px;font-weight: 500">&nbsp; &nbsp;&nbsp;测试报告的链接为:<a href="http://ci.qtrade.com.cn/jenkins/view/backend-qa/job/be-qa-qtrade-api-test/allure/" style="text-decoration: none">http://ci.qtrade.com.cn/jenkins/view/backend-qa/job/be-qa-qtrade-api-test/allure/</a></div>
    <div style="line-height: 1.5;font-size: 16px;font-weight: 500">&nbsp; &nbsp;&nbsp;详细附件可登陆jenkins查看</div>
    '''.format(total_num,pass_count,fail_count,error_count)
    try:
        mail = yagmail.SMTP(**EMAIL_INFO)

        mail.send(to=TO, cc=CC, subject=subject,
                  contents=[html])
    except Exception as e:
        log.error("发送邮件出错了，错误信息是:\n%s" % traceback.format_exc())
    else:
        log.info("发送邮件成功")


if __name__ == '__main__':
    # path = 'F:\\PycharmProjects\\atp\\cases\\qt_base\\apis\\获取标签下成员列表.yaml'
    #     # print(os.path.split(path))
    # print(get_filename('E:/PycharmProjects/apitest/atp/harfile'))
    pass
