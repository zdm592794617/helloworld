from utils.functions import *
import json
import os
from utils.tools import variable_replace
from config.setting import log, CASE_PATH, PARAM_PATTERN
from utils.tools import get_filename, check_dict


def load_testcase(apifile, datafile='apifile'):
    '''返回一个列表，用于参数化'''
    api_request_dic = {}
    # 将api里绑定的方法替换为值
    api_obj = prase_data(load_file(apifile))
    api_str = json.dumps(api_obj)
    if datafile == 'apifile':
        datafile = apifile.replace('apis', 'data').replace('yaml', 'csv')
    datafile_path = os.path.join(datafile)
    request_data = []
    if os.path.exists(datafile_path):
        data = load_file(datafile_path)
        for t in data:
            api_request_dic = {}
            api_str_replaced = variable_replace(PARAM_PATTERN, api_str, t)
            api_request_dic = json.loads((api_str_replaced))
            request_data.append(api_request_dic)
    else:
        request_data.append(api_obj)
    return request_data


def load_proj_testcase(projname):
    data_list = []
    files = get_filename(os.path.join(CASE_PATH, projname, 'apis'))
    for f in files:
        datas = load_testcase(f)
        for data in datas:
            test_title = data.pop('test_info', '没有titile')
            if check_dict(test_title):
                test_title = test_title['title']
            data_list.append((test_title, data))
    return data_list


if __name__ == '__main__':
    data = {'test_case': [{'test': {'name': 'qt_base/apis/企点右面版登录', 'extract': {'access_token': 'access_token'}}}, {
        'test': {'name': '企点版本', 'method': 'POST',
                 'url': 'https://test.qtrade.com.cn/qtrade_bond/api/qidianVersion/medalInfo.do',
                 'cookies': {'appletree_key': '${access_token}$'},
                 'headers': {'Accept': 'application/json, text/plain, */*', 'Accept-Encoding': 'gzip, deflate',
                             'Accept-Language': 'en-US,en;q=0.8', 'Connection': 'keep-alive', 'Content-Length': '39',
                             'Content-Type': 'application/x-www-form-urlencoded',
                             'Cookie': 'appletree_key=22c9a34e4931600d2b6d25be7f7132d7351f4c47; appletree_key_en=6B8FA17281CE0AC3CC35BB7A71038D07BE916BF3F1F881D10EB3E44C43C11173B12634C60BC392D9BA098F513DEEAD00',
                             'Host': 'test.qtrade.com.cn', 'Origin': 'https://test.qtrade.com.cn',
                             'User-Agent': 'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) QQ/3.5.17022.201 Chrome/43.0.2357.134 Safari/537.36 QBCore/3.43.1286.400 QQBrowser/9.0.2524.400',
                             'X-Tingyun-Id': '1RcVY-ruV8A;r=706388603'}, 'params': '',
                 'data': {'openId': 'DEFD98C6C0165F4EDE725643646EFB0B'}, 'validate': {'eq': {'ret': '1', 'retdata': {
                'fromUser': {'hasMedal': False, 'hasPop': False}, 'toUser': {'hasMedal': False, 'hasPop': False}},
                                                                                             'retmsg': 'OK'}}}}]}
    print(load_testcase(data))
