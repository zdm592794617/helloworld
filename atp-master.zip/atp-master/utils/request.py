import requests, traceback
from config.setting import HOST, log
from urllib.parse import urljoin
import urllib3
urllib3.disable_warnings()


class MyRequest:
    def __init__(self, url, request_data, cookie=None):
        self.cookies = cookie
        self.url = url
        self.request_data = request_data
        self.req()

    def req(self):
        try:
            host = self.request_data.pop('proxy', HOST)
            url = urljoin(host, self.url)
            method = self.request_data.pop('method')
            response = requests.request(method, url,cookies=self.cookies, verify=False, **self.request_data)
            result = response.json()
            cookies = response.cookies
        except Exception as e:
            log.error('请求 %s的时候出错了，错误信息是 %s' % (self.request_data, traceback.format_exc()))
            self.result = {"msg": "请求接口出错了", "error_msg": traceback.format_exc()}
            self.text = ' {"msg":"请求接口出错了","error_msg":%s} ' % traceback.format_exc()
        else:
            self.result = result
            self.cookies = cookies

