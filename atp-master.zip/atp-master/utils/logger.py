
import logging
from logging import handlers

class Logger:
    def __init__(self,file_name,level='debug',backCount=5,when='D',interval=1):
        logger = logging.getLogger(file_name)
        logger.setLevel(self.__get_level(level))
        c1 = logging.StreamHandler()
        b1 = handlers.TimedRotatingFileHandler(file_name,when=when,backupCount=backCount,interval=interval,encoding='utf-8')
        fmt = logging.Formatter('%(asctime)s - %(pathname)s[line:%(lineno)d] - %(levelname)s: %(message)s')
        c1.setFormatter(fmt)
        b1.setFormatter(fmt)
        logger.addHandler(c1)
        logger.addHandler(b1)
        self.debug = logger.debug
        self.warning = logger.warning
        self.info = logger.info
        self.error = logger.error

    def __get_level(self, str):
        level = {
            'debug': logging.DEBUG,
            'info': logging.INFO,
            'warn': logging.WARNING,
            'error': logging.ERROR
        }
        str = str.lower()
        result = level.get(str,logging.DEBUG)
        return result


if __name__ == '__main__':
    log = Logger('test.log',when='S',interval=3)
    log.debug("debug信息")
    log.info("info信息")
    log.error("error信息")

