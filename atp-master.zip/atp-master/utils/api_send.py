import os
from config.setting import CASE_PATH
from utils.request import MyRequest
from utils.tools import depend_replace, get_value, check_dict
from utils.validates import ParseResponse
from utils.load_testcase import load_testcase
import urllib3
import allure

urllib3.disable_warnings()


def send_request(request_data, cookie=None):
    test_cases = request_data.get('test_case', [])
    premise_dic = {}
    validate_data = {}
    response_result = {}
    response_cookie = {}
    for test_case in test_cases:
        if check_dict(test_case):
            test_rquest_data = {}
            test_rquest_data = test_case.get('test')
            if check_dict(test_rquest_data):
                url = test_rquest_data.pop('url', '')
                extract_var = test_rquest_data.pop('extract', '')
                test_rquest_data = depend_replace(r'\${(.*)}\$', test_rquest_data, premise_dic)
                # 前置的用例没有参数化时可以直接用前置用例的文件
                if url == '':
                    test_name = test_rquest_data.pop('name', '')
                    api_file = test_name + '.yaml'
                    api_file_path = os.path.join(CASE_PATH, api_file)
                    '''前置用例为文件时，仅支持yaml中为单个用例,不带参数的情况'''
                    test_rquest_data = load_testcase(api_file_path)[0].get('test_case')[0].get('test')
                    url = test_rquest_data.pop('url', '')
                test_name = test_rquest_data.pop('name', '')
                output_var = test_rquest_data.pop('output', '')
                validate_data = test_rquest_data.pop('validate', '')
                allure.attach(url, '请求的url')
                allure.attach(str(test_rquest_data), '请求的参数')
                rq = MyRequest(url, test_rquest_data, cookie)
                response_result = rq.result
                response_cookie = rq.cookies
                allure.attach(str(response_result), '接口返回的结果')
                if extract_var:
                    for k, v in extract_var.items():
                        premise_dic[k] = get_value(response_result, v)
            else:
                allure.attach(test_case, 'yaml文件格式错误')
    return validate_data, response_result, response_cookie


def send_request_check(request_data, cookie=None):
    validate_data, response_result, response_cookie = send_request(request_data, cookie)
    compare_data = ParseResponse(validate_data, response_result)
    result = compare_data.result
    reasons = compare_data.reasons
    return result, reasons


if __name__ == '__main__':
    request_data = {'test_case': {
        'test': {'name': '获取标签下成员列表', 'method': 'POST', 'url': '/qtrade_ums/api/panel/friend/list.do',
                  'headers': {'Content-Type': 'application/x-www-form-urlencoded'},
                  'proxies': {'https': 'http://localhost:8888'}, 'data': {'tagId': '9d16c85628de458ab962ad5b13e41568'},
                  'validate': {'eq': {'code': 0, 'msg': '成功'}}}}}
    print(send_request(request_data))
