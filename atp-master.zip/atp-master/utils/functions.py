import re,json,time
from config.setting import ENV, GLOBAL_VARS_PATH
from utils.operate_file import load_file, write_json_file
from config.setting import log
from utils.tools import rex_match


def load_global_var():
    global_data = load_file(GLOBAL_VARS_PATH)
    if ENV.lower() == 'test':
        return global_data.get('test_global_var', {})
    else:
        return global_data.get('online_global_var', {})


def get_global_var(key):
    data = load_global_var()
    return data.get(key, '')


def set_global_var1(key, value):
    global_data = load_file(GLOBAL_VARS_PATH)
    if ENV.lower() == 'test':
        test_global_var = global_data.get('test_global_var', {})
        test_global_var[key] = value
        global_data['test_global_var'] = test_global_var
    else:
        online_global_var = global_data.get('online_global_var', {})
        online_global_var[key] = value
        global_data['online_global_var'] = online_global_var
    write_json_file(global_data, GLOBAL_VARS_PATH)
    return ''


def timestamp_to_str(format='%Y-%m-%d %H:%M:%S'):
    '''这个是把时间戳转换成格式化好的实际'''
    return time.strftime(format)

def get_timestamp():
    '''13位时间戳'''
    return str(int(round(time.time() * 1000)))

def prase_data(data):
    '''data 为json类型 <get_strftime(delt=24*3600*2,format='%Y-%m-%d 00:00:00')>'''

    rex_p = r'<(.*?)>'
    matched_data = rex_match(rex_p, data)
    if matched_data:
        for tmp in matched_data:
            try:
                data = json.dumps(data)
                data = data.replace(tmp, eval(tmp))
            except Exception as e:
                log.error(e)
                log.error('错误调用的方法为%s,数据为%s'%(tmp,data))
                data = tmp
            data = json.loads(re.sub('[<|>]', '', data))
    return data


if __name__ == '__main__':
    print(timestamp_to_str('%Y%m%d'))