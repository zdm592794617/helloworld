# encoding:utf8
from utils.tools import get_value
from config.setting import log
import allure


class ParseResponse:
    fuhao = {
        'eq': '==',
        'ne': '!=',
        'lt': '<',
        'gt': '>',
        'le': '<=',
        'ge': '>=',
        'in': 'in',
        'not in': 'not in',
        'type': 'type'
    }

    def __init__(self, expect, response):
        self.expect = expect
        self.response = response
        self.compare()

    def compare(self):
        '''
             { eq: { status_code: '200', ret: 0 },
     'not in': [ 'data' ] } }

        '''
        self.result = False
        self.reasons = []
        for f in self.expect:
            if f not in self.fuhao.keys():
                log.error('比较符号%s不支持' % f)
            else:
                for k in self.expect[f]:
                    actual_data = get_value(self.response, k)
                    if actual_data != '':
                        if f !='type':
                            com = '"{}"{}"{}"'.format(self.expect[f][k], self.fuhao[f], actual_data)
                            try:
                                self.result = eval(com)
                            except Exception as e:
                                log.error('断言出错，断言的字符串为{}，错误信息为{}'.format(com, e))
                                self.result = False
                        else:
                            self.result = isinstance(actual_data, eval(self.expect[f][k]))
                            com ="接口返回{}类型为{}".format(actual_data,self.expect[f][k])
                        allure.attach(k, '校验字段')
                        allure.attach(com, '校验的字符串')
                        if not self.result:
                            reason = '%s结果不匹配,%s不成立' % (k, com)
                            self.reasons.append(reason)
                    else:
                        self.result = False
                        reason = '请求返回中%s不存在,实际结果为%s' % (k, self.response)
                        self.reasons.append(reason)


if __name__ == '__main__':
    pass
