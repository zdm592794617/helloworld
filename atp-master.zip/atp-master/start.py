import sys, os,shutil,time
BASE_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE_PATH)

import urllib3
urllib3.disable_warnings()

import subprocess
import pytest
from config.setting import CASE_PATH, REPORT_PATH,log

if __name__ == '__main__':
    args = sys.argv
    t = time.strftime('%Y%m%d%H%M%S')
    result_path = os.path.join(REPORT_PATH, 'xml')
    report_path = os.path.join(REPORT_PATH, 'html')
    try:
        shutil.rmtree(result_path)
    except Exception as e:
        pass
    mark = 'all'
    num = '0'
    pytest.main(['-q', '-s', CASE_PATH, '-m', mark,'-n',num, '--alluredir', result_path])
    command = "allure generate  %s -o %s --clean" % (result_path, report_path)
    subprocess.call(command, shell=True)
