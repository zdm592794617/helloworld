import os
from collections import OrderedDict
import yaml
import urllib3
urllib3.disable_warnings()

path = os.path.dirname(__file__)

def ordered_yaml_dump(data, stream=None, Dumper=yaml.SafeDumper, **kwds):
    def dict_representer(dumper, data):
        return dumper.represent_mapping(
            yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
            data.items())
    yaml.SafeDumper.add_representer(OrderedDict, dict_representer)
    return yaml.dump(data, stream, yaml.SafeDumper, **kwds)

def write_yaml_file(data_dic,yaml_file):
    if not os.path.exists(yaml_file):
        new_yaml_file = os.path.join(path, yaml_file)
        f = open(new_yaml_file, 'w', encoding='utf-8')
        ordered_yaml_dump(data_dic, f, encoding='utf-8', allow_unicode='True')
        f.close()

#返回格式的dic,生成符合格式的yaml
def ge_yaml(data_dic,file_name):
    data_dic_o=OrderedDict()
    test_case = []
    test_info = {}
    test = OrderedDict()
    data_dic_o['test'] = data_dic
    test_case.append(data_dic_o)
    test_info['title'] = file_name
    test['test_info'] = test_info
    test['test_case'] = test_case
    return test
