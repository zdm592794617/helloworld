import os
from utils.logger import Logger


TEST_AREA = ''
TEST_PROJECT = 'qt_independentpanel'

ENV = 'test'  # 默认使用测试环境

host_map = {
    "test": "https://test.qtrade.com.cn",
    "dev": "http://118.24.3.40:81/"
}

HOST = host_map.get(ENV)

PARAM_PATTERN = r'\${(.*?)}'

DEPENDANT_PATTERN = r'\${(.*?)}\$'


EMAIL_INFO = {
    'user': 'het@qtrade.com.cn',
    'host': 'smtp.exmail.qq.com',
    'password': 'B6F62EFGFHf3kzXh'
}

MYSQL_INFO = {
    'host': '',
    'db': '',
    'user': '',
    'password': '123456',
    'charset': 'utf8',
    'port': 3306,
    'autocommit': True,
}

# TO = ['het@qtrade.com.cn','tangyuewen@qtrade.com.cn','lijun@qtrade.com.cn','gonghaiping@qtrade.com.cn']
TO = ['het@qtrade.com.cn']

CC = []

LOG_LEVEL = 'debug'

BASE_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

CASE_PATH = os.path.join(BASE_PATH, 'cases')  # 查找用例的目录

LOG_PATH = os.path.join(BASE_PATH, 'logs', 'test.log')

REPORT_PATH = os.path.join(BASE_PATH, 'report')

RESULT_PATH = os.path.join(BASE_PATH, 'result')
HAR_PATH = os.path.join(BASE_PATH, 'harfile')

GLOBAL_VARS_PATH = os.path.join(BASE_PATH,'config','global_var.json')

log = Logger(file_name=LOG_PATH, level=LOG_LEVEL)

CASE_FILE_START = 'test'  # 这个找用例的规则，以什么开头就运行
