import requests
import jsonpath
import urllib3

urllib3.disable_warnings()

from yaml_oper import *

url = 'https://dev.qtrade.com.cn/qtrade-activity/v2/api-docs'
path = os.path.dirname(__file__)
dir_name = 'apis'


# 新建接口文档目录
def check_mkdir(dir_name):
    try:
        os.mkdir(dir_name)
    except Exception as e:
        pass


# 从文档获取接口的相关信息
def get_data_from_swagger_doc():
    rq = requests.get(url, verify=False).json()
    base_path = rq.get('basePath')
    paths_dic = rq.get('paths')
    for api, data in paths_dic.items():
        uri = base_path + api
        for m, v in data.items():
            data_dic = OrderedDict()
            temp = {}
            method = m
            name = v['tags'][0] + v['summary']
            name = name.replace(':', '')
            content_type = v['produces']
            data_dic['name'] = name
            data_dic['url'] = uri
            data_dic['method'] = method
            temp['Content-Type'] = content_type[0]
            data_dic['headers'] = temp
            parameters = jsonpath.jsonpath(data, '$..name')
            if parameters:
                data = {}
                for p in parameters:
                    data[p.strip()] = '${' + p.strip() + '}'
                data_dic['params'] = data
            data_dic['validate'] = {'eq': {'ret': 0}}
            yaml_file = os.path.join(dir_name, name + '.yaml')
            test = ge_yaml(data_dic, name)
            write_yaml_file(test, yaml_file)


check_mkdir(dir_name)
get_data_from_swagger_doc()
