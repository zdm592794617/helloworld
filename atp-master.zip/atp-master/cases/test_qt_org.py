import allure
import pytest
from utils.api_send import send_request_check
from utils.load_testcase import load_proj_testcase

@allure.feature('qt_org')
class TestQtOrg():
    @pytest.mark.all
    @pytest.mark.qt_org
    @allure.story('机构管理后台')
    @pytest.mark.parametrize('title,request_data', load_proj_testcase('qt_org'),ids=[])
    @allure.title('{title}')
    def test_qt_chat(self,title,request_data,qt_org_login):
        result, reasons =send_request_check(request_data,qt_org_login)
        assert result,reasons