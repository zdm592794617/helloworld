import allure
import pytest
from utils.api_send import send_request_check
from utils.load_testcase import load_proj_testcase

@allure.feature('qt_base')
@pytest.mark.all
class TestQtBase():
    @allure.story('通讯录相关')
    @pytest.mark.qt_base
    @pytest.mark.parametrize('title,request_data', load_proj_testcase('qt_base'))
    @allure.title('{title}')
    def test_qt_base(self,title,request_data,qt_qidian_login):
        result, reasons =send_request_check(request_data,qt_qidian_login)
        assert result,reasons

