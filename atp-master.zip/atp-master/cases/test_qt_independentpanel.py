import allure
import pytest
from utils.api_send import send_request_check
from utils.load_testcase import load_proj_testcase

@allure.feature('qt_independentpanel')
class TestQtIndependentpanel():

    @pytest.mark.qt_independentpanel
    @pytest.mark.all
    @allure.story('独立面板')
    @pytest.mark.parametrize('title,request_data', load_proj_testcase('qt_independentpanel'),ids=[])
    @allure.title('{title}')

    def test_qt_homepage(self,title,request_data,qt_qidian_login):
        result, reasons =send_request_check(request_data,qt_qidian_login)
        assert result,reasons

