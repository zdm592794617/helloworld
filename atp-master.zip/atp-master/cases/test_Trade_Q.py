import allure
import pytest
from utils.api_send import send_request_check
from utils.load_testcase import load_proj_testcase

@allure.feature('qt_Trade_Q')
@pytest.mark.all
@pytest.mark.qt_Trade_Q
class TestTradeQ():
    @pytest.mark.zijin
    @allure.story('资金')
    @pytest.mark.parametrize('title,request_data', load_proj_testcase('Trade_Q/zijin'),ids=[])
    @allure.title('{title}')
    def test_qt_zijin(self,title,request_data,qt_qidian_login):
        result, reasons =send_request_check(request_data,qt_qidian_login)
        assert result,reasons

    @allure.story('现券')
    @pytest.mark.xianquan
    @pytest.mark.parametrize('title,request_data', load_proj_testcase('Trade_Q/xianquan'),ids=[])
    @allure.title('{title}')
    def test_qt_xianquan(self,title,request_data,qt_qidian_login):
        result, reasons =send_request_check(request_data,qt_qidian_login)
        assert result,reasons

    @allure.story('NCD')
    @pytest.mark.xianquan
    @pytest.mark.parametrize('title,request_data', load_proj_testcase('Trade_Q/NCD'),ids=[])
    @allure.title('{title}')
    def test_qt_ncd(self,title,request_data,qt_qidian_login):
        result, reasons =send_request_check(request_data,qt_qidian_login)
        assert result,reasons