import allure
import pytest
from utils.api_send import send_request_check
from utils.load_testcase import load_proj_testcase

@allure.feature('qt_homepage')
class TestQtHomepage():

    @pytest.mark.qt_homepage
    @pytest.mark.all
    @allure.story('右面版')
    @pytest.mark.parametrize('title,request_data', load_proj_testcase('qt_homepage'),ids=[])
    @allure.title('{title}')

    def test_qt_homepage(self,title,request_data,qt_qidian_login):
        result, reasons =send_request_check(request_data,qt_qidian_login)
        assert result,reasons

