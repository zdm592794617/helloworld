import base64
import json
import jsonpath
import  re
from utils.tools import get_filename,rex_match
from config.setting import HAR_PATH
from yaml_oper import *


def get_value(d, k):
    '这个函数是用来从返回结果里面获取key的'
    result = jsonpath.jsonpath(d, '$..%s' % k)
    if result:
        return result[0]
    return ''

#格式化header,cookies等
def generate_dict(data_list):
    '''
    :param data_list: [{"name":"org_key","value":"qidian_org_id_hj02"},{"name":"org_session_key","value":"07720bd44e90ccc2225d227afa87ebb3cd152c2f"}]
    :return: {"org_key":"qidian_org_id_hj02","org_session_key":"07720bd44e90ccc2225d227afa87ebb3cd152c2f"}
    '''
    if data_list:
        out_dict={}
        for d in data_list:
            key = d.get('name')
            out_dict[key] = d.get('value')
        return out_dict
    else:
        return ''

#获取url的最后一个字符
r=r'([^/]+(?!.*/)).do'


har_files = get_filename(HAR_PATH)
for har_file in har_files:
    try:
        if os.path.splitext(har_file)[1]=='.har':
            with open (har_file,encoding='UTF-8') as f:
                data = f.read()
            if data.startswith(u'\ufeff'):
                data = data.encode('utf8')[3:].decode('utf8')
            data_obj = json.loads(data)
            entries = get_value(data_obj,'entries')
            for d in entries:
                test_info={}
                test_case=[]
                test = OrderedDict()
                data_dic = OrderedDict()
                data_dic_o = OrderedDict()
                d1={}
                cookies={}
                response_eq={}
                file_name = os.path.splitext(har_file)[0]
                request_data = d.get('request')
                response_data = d.get('response').get('content').get('text')
                #fiddler 导出的har文件没有断言内容,默认断言内容为ret=0
                if response_data:
                    response_text= str(base64.b64decode(response_data),'utf-8')
                    response_eq['eq'] = json.loads(response_text)
                else:
                    response_eq['eq']={'ret':0}
                url =  request_data.get('url').replace('https://test.qtrade.com.cn','')
                url_s = rex_match(r,url)[0]
                data_dic['name'] = file_name.split('\\')[-1]+url_s
                data_dic['method'] = request_data.get('method')
                data_dic['url'] = url
                cookies_list = request_data.get('cookies')
                headers_list = request_data.get('headers')
                queryString_list = request_data.get('queryString')
                #data_dic['cookies'] = generate_dict(cookies_list)
                header_dic = generate_dict(headers_list)
                #只要header 里的content-type
                data_dic['headers'] = {'Content-Type':header_dic.get('Content-Type','application/x-www-form-urlencoded')}
                data_dic['params'] = generate_dict(queryString_list)
                postData_list = request_data.get('postData',{})
                if postData_list !={}:
                    content_type= postData_list.get('mimeType')
                    if content_type=='application/json':
                        data_dic['json']=json.loads(postData_list.get('text'))
                    else:
                        postData_list=postData_list.get('params')
                        data_dic['data'] = generate_dict(postData_list)
                data_dic['validate'] = response_eq
                test=ge_yaml(data_dic, file_name.split('\\')[-1]+url_s)
                yaml_file = os.path.join(file_name +url_s+'.yaml')
                write_yaml_file(test, yaml_file)
    except Exception as e:
        print("%s文件生成yaml失败,失败原因%s"%(har_file,e))
