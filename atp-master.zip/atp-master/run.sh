#! /bin/bash
port=24921
PID=`ps -ef | grep $port | grep -v grep | awk '{print $2}'`
if [ -n "$PID" ];then
    echo "`date +%F%H%M%S` testReport service $PID is running, stop it"
    kill -9 $PID
fi
cd /data/apitest/atp
echo "开始拉取最新代码....."
sudo git reset --hard
sudo git pull origin
echo "`date +%F%H%M%S` start running test"
python3.8 start.py


