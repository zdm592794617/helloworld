import os
import pytest
from utils.api_send import send_request
from config.setting import CASE_PATH
from utils.load_testcase import load_testcase
from utils.tools import get_value,send_mail
from utils.functions import get_global_var


@pytest.fixture(scope='session',autouse=True)
def qt_qidian_login():
    response_data = send_request(load_testcase(os.path.join(CASE_PATH, 'login', 'apis', '企点右面版登录.yaml'))[0])
    response = response_data[1]
    access_token = get_value(response, 'access_token')
    cookies = {'appletree_key': access_token}
    return cookies

@pytest.fixture(scope='session',autouse=True)
def qt_org_login():
    response_data = send_request(load_testcase(os.path.join(CASE_PATH, 'login', 'apis', '机构后台登录.yaml'))[0])
    cookie_data = response_data[2]
    #cookies = {'org_key': cookie_data['org_key'], 'org_session_key': cookie_data['org_session_key'],'org_token':cookie_data['org_token']}
    return cookie_data

def pytest_terminal_summary(terminalreporter, exitstatus, config):
    '''收集测试结果并发送邮件'''
    total=terminalreporter._numcollected
    pass_num=len([i for i in terminalreporter.stats.get('passed', []) if i.when != 'teardown'])
    failed_num=len([i for i in terminalreporter.stats.get('failed', []) if i.when != 'teardown'])
    error_num = len([i for i in terminalreporter.stats.get('error', []) if i.when != 'teardown'])
    deselected_num = len([i for i in terminalreporter.stats.get('deselected', [])])
    #send_mail(total,pass_num,failed_num,error_num)


